# Theepan Shopify Reference Component Showcase

A single-route React + Vite SPA based on:

- International Shopify reference: **Gymshark**
- Indian Shopify reference: **Mokobara**

## Assignment compliance

- One SPA, one `/` route
- Both reference component systems shown on the same page
- Placeholder imagery only
- Original/paraphrased copy
- No Shopify Liquid/theme copying
- No backend cart, checkout or payments
- Component inventory matches the rendered order
- GitHub Pages workflow included

## Repository documents

- `REFERENCE_APPROVAL.md`
- `RESEARCH_REPORT.md`
- `COMPONENT_INVENTORY.md`
- `SUBMISSION_LINKS.md`

## Run locally

```bash
npm install
npm run dev
```

## Production validation

```bash
npm run build
npm run preview
```

## GitHub Pages

1. Create repository `theepan-shopify-component-showcase`.
2. Push to `main`.
3. Choose **Settings → Pages → GitHub Actions**.
4. Wait for the included workflow to finish.
5. Fill `SUBMISSION_LINKS.md`.

Expected URL:

`https://<github-username>.github.io/theepan-shopify-component-showcase/`
