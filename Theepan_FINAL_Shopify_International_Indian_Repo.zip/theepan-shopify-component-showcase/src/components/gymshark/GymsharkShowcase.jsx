import { useState } from 'react'
import PlaceholderFrame from '../shared/PlaceholderFrame.jsx'

const drops = [
  ['Heavyweight Lift Tee', 'Oversized / training', '$42'],
  ['Power Short 7"', 'Regular / lifting', '$38'],
  ['Core Seamless Top', 'Body fit / conditioning', '$46'],
  ['Rest Day Jogger', 'Relaxed / recovery', '$58'],
]

function PromoTicker({ messages }) { return <div className="gym-promo">{messages.join(' / ')}</div> }
function PerformanceHeader({ bagCount }) { return <header className="gym-header"><a className="gym-logo" href="#gymshark">FORGE/ATHLETIC</a><nav aria-label="Forge Athletic primary"><a href="#gym-drops">Women</a><a href="#gym-drops">Men</a><a href="#gym-drops">Accessories</a></nav><div><button aria-label="Search products">Search</button><button aria-label={`Bag with ${bagCount} items`}>Bag {bagCount}</button></div></header> }
function ImpactHero({ campaign, actions, artLabel }) { return <section className="gym-hero"><PlaceholderFrame label={artLabel} mode="signal" shape="cinema" /><div className="gym-hero__overlay"><p>{campaign.eyebrow}</p><h3>{campaign.title}</h3><div className="gym-actions">{actions.map((action) => <a href="#gym-drops" key={action}>{action}</a>)}</div></div></section> }
function ActivityCategoryRail({ categories }) { return <section className="gym-categories">{categories.map(({ title, copy, mode }) => <article key={title}><PlaceholderFrame label={`${title} category`} mode={mode} shape="portrait" /><div><h3>{title}</h3><p>{copy}</p><a href="#gym-drops">Explore</a></div></article>)}</section> }
function AudienceToggle({ audience, onChange }) { return <div className="segmented" aria-label="Choose audience">{['Women', 'Men'].map((item) => <button key={item} className={audience === item ? 'active' : ''} onClick={() => onChange(item)} aria-pressed={audience === item}>{item}</button>)}</div> }
function ProductDropGrid({ products, onQuickAdd }) { return <div className="gym-product-grid">{products.map(([name, spec, price], index) => <article key={name}><PlaceholderFrame label={`${name} product`} mode={index % 2 ? 'steel' : 'fog'} shape="square" /><small>{index < 2 ? 'New' : 'Core'}</small><h4>{name}</h4><p>{spec}</p><div><strong>{price}</strong><button onClick={onQuickAdd}>Quick add</button></div></article>)}</div> }
function TrainingEditorial({ title, artLabel }) { return <section className="gym-editorial"><div><p>Training content</p><h3>{title}</h3><a href="#gymshark">Read the training story</a></div><PlaceholderFrame label={artLabel} mode="cobalt" shape="wide" /></section> }
function AppMembershipBanner({ title, copy, cta }) { return <section className="gym-app"><strong>{title}</strong><p>{copy}</p><a href="#gymshark">{cta}</a></section> }

export default function GymsharkShowcase() {
  const [audience, setAudience] = useState('Women')
  const [bagCount, setBagCount] = useState(0)
  return (
    <div className="reference reference--gym">
      <PromoTicker messages={['MEMBER EARLY ACCESS', 'FREE DELIVERY OVER $75', '30-DAY RETURNS']} />
      <PerformanceHeader bagCount={bagCount} />
      <ImpactHero campaign={{ eyebrow: 'New conditioning collection', title: 'Built for the work before the result.' }} actions={['Shop women', 'Shop men', 'Shop accessories']} artLabel="High-intensity campaign" />
      <ActivityCategoryRail categories={[{ title: 'Lift', copy: 'Strength-first essentials', mode: 'ink' }, { title: 'Run', copy: 'Light layers and storage', mode: 'cobalt' }, { title: 'Condition', copy: 'Fast, flexible training', mode: 'signal' }]} />
      <section id="gym-drops" className="gym-drops"><div className="gym-heading"><div><p>Latest product drops</p><h3>Technical product, fast decisions.</h3></div><AudienceToggle audience={audience} onChange={setAudience} /></div><p className="audience-status">Sample shelf: {audience}</p><ProductDropGrid products={drops} onQuickAdd={() => setBagCount((count) => count + 1)} /></section>
      <TrainingEditorial title="Commerce continues into coaching and community." artLabel="Athlete editorial" />
      <AppMembershipBanner title="THE BEST OF FORGE, ANYTIME." copy="Exclusive drops, training guidance and in-store access in one member experience." cta="Get the sample app" />
    </div>
  )
}
