export default function ReferenceLabel({ index, reference, thesis }) {
  return (
    <header className="reference-label">
      <span>{index}</span>
      <div>
        <p>Shopify reference</p>
        <h2>{reference}</h2>
        <p>{thesis}</p>
      </div>
    </header>
  )
}
