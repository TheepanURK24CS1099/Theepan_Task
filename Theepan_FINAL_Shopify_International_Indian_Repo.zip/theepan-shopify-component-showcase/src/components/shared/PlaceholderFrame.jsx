export default function PlaceholderFrame({ label, mode = 'steel', shape = 'wide' }) {
  return (
    <div
      className={`frame frame--${mode} frame--${shape}`}
      role="img"
      aria-label={`${label} placeholder artwork`}
    >
      <span>{label}</span>
      <i aria-hidden="true" />
    </div>
  )
}
