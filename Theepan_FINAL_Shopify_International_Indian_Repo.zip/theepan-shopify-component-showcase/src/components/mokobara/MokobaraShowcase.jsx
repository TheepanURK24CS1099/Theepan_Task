import { useState } from 'react'
import PlaceholderFrame from '../shared/PlaceholderFrame.jsx'

const luggage = [
  ['Transit Cabin', 'Cabin · 38 L', '₹6,999', '₹13,999', ['Sunray', 'Money', 'Brown']],
  ['Aisle Check-in', 'Check-in · 72 L', '₹8,499', '₹15,999', ['Matcha', 'Cloud', 'Blue']],
  ['Hovercraft Pack', 'Work + travel · 30 L', '₹5,999', '₹9,999', ['Black', 'Stone', 'Green']],
  ['Journey Set', 'Cabin + check-in', '₹16,999', '₹38,999', ['Sunray', 'Brown', 'Grey']],
]

function SaleAnnouncement({ message }) { return <div className="moko-promo">{message}</div> }
function TravelHeader({ menuOpen, onMenuToggle }) { return <><header className="moko-header"><button className="moko-menu" aria-expanded={menuOpen} onClick={onMenuToggle}>Menu</button><a className="moko-logo" href="#mokobara">GO/BRIGHT</a><nav aria-label="Go Bright primary"><a href="#moko-products">Luggage</a><a href="#moko-products">Backpacks</a><a href="#moko-products">Totes</a><a href="#moko-products">Accessories</a></nav><div><button aria-label="Search">Search</button><button aria-label="Cart">Cart</button></div></header>{menuOpen && <nav className="moko-mobile-nav" aria-label="Go Bright mobile"><a href="#moko-products">By size</a><a href="#moko-collections">By collection</a><a href="#moko-compare">By use</a></nav>}</> }
function ColourCampaignHero({ title, actions, artLabel }) { return <section className="moko-hero"><div className="moko-hero__copy"><p>Indian travel design / colour-forward utility</p><h3>{title}</h3><div>{actions.map((action) => <a key={action.label} href={action.href}>{action.label}</a>)}</div></div><PlaceholderFrame label={artLabel} mode="signal" shape="cinema" /></section> }
function TravelCollectionGrid({ collections }) { return <section id="moko-collections" className="moko-collections">{collections.map(({ title, copy, mode }) => <article key={title}><PlaceholderFrame label={`${title} collection`} mode={mode} shape="portrait" /><h3>{title}</h3><p>{copy}</p><a href="#moko-products">View collection</a></article>)}</section> }

function LuggageCard({ item, index }) {
  const [selected, setSelected] = useState(0)
  const [added, setAdded] = useState(false)
  const [name, detail, price, oldPrice, colours] = item
  return <article className="moko-card"><PlaceholderFrame label={`${name} product`} mode={index % 2 ? 'sand' : 'signal'} shape="square" /><small>{index === 0 ? 'Bestseller' : index === 2 ? 'Hot' : 'Travel edit'}</small><h4>{name}</h4><p>{detail}</p><div className="moko-pricing"><strong>{price}</strong><del>{oldPrice}</del></div><div className="moko-colours" aria-label={`Colour choices for ${name}`}>{colours.map((colour, colourIndex) => <button key={colour} aria-label={`Select ${colour}`} aria-pressed={selected === colourIndex} className={selected === colourIndex ? 'selected' : ''} onClick={() => setSelected(colourIndex)}>{colour.slice(0, 1)}</button>)}</div><button className="moko-add" onClick={() => setAdded(true)}>{added ? 'Added ✓' : 'Quick add sample'}</button></article>
}

function BestsellerLuggageGrid({ products }) { return <section id="moko-products" className="moko-products"><div className="moko-heading"><div><p>Bestsellers</p><h3>Price, capacity and colour at a glance.</h3></div><a href="#mokobara">View all sample products</a></div><div className="moko-grid">{products.map((item, index) => <LuggageCard item={item} index={index} key={item[0]} />)}</div></section> }

function SizeComparison({ sizes }) {
  const [selectedSize, setSelectedSize] = useState(sizes[0].name)
  const selected = sizes.find((size) => size.name === selectedSize)
  return <section id="moko-compare" className="moko-compare"><div className="moko-compare__copy"><p>Choose by trip length</p><h3>Turn luggage sizing into a guided decision.</h3><div className="moko-size-tabs" role="tablist" aria-label="Luggage size comparison">{sizes.map((size) => <button role="tab" aria-selected={selectedSize === size.name} className={selectedSize === size.name ? 'active' : ''} onClick={() => setSelectedSize(size.name)} key={size.name}>{size.name}</button>)}</div><p><strong>{selected.name}</strong> sample guidance: {selected.copy}</p></div><PlaceholderFrame label={`${selected.name} luggage size diagram`} mode="fog" shape="wide" /></section>
}
function LoyaltyBanner({ benefits }) { return <section className="moko-loyalty"><div><p>Sample membership</p><h3>Reward repeat travellers without interrupting first-time shopping.</h3></div><ul>{benefits.map((benefit) => <li key={benefit}>{benefit}</li>)}</ul><a href="#mokobara">Explore membership</a></section> }
function StoreLocatorStory({ artLabel }) { return <section className="moko-stores"><PlaceholderFrame label={artLabel} mode="cobalt" shape="wide" /><div><p>Online + retail</p><h3>Find a store, see colours in person, continue shopping online.</h3><a href="#mokobara">Find a sample store</a></div></section> }
function NewsletterFooter() { return <footer className="moko-footer"><p>Travel drops, packing notes and member previews.</p><form onSubmit={(event) => event.preventDefault()}><label htmlFor="moko-email">Email address</label><input id="moko-email" type="email" placeholder="name@example.com" required /><button type="submit">Join</button></form></footer> }

export default function MokobaraShowcase() {
  const [menuOpen, setMenuOpen] = useState(false)
  return (
    <div className="reference reference--moko">
      <SaleAnnouncement message="Sample sale up to 50% · Free shipping · Colourful travel, simplified" />
      <TravelHeader menuOpen={menuOpen} onMenuToggle={() => setMenuOpen((value) => !value)} />
      <ColourCampaignHero title="Make every arrival easier to spot." actions={[{ label: 'Shop luggage', href: '#moko-products' }, { label: 'Explore collections', href: '#moko-collections' }]} artLabel="Colourful luggage campaign" />
      <TravelCollectionGrid collections={[{ title: 'Cabin ready', copy: 'Quick trips and overhead storage', mode: 'signal' }, { title: 'Check-in', copy: 'Longer travel and larger capacity', mode: 'cobalt' }, { title: 'Work carry', copy: 'Devices, commutes and short travel', mode: 'steel' }, { title: 'Travel sets', copy: 'Coordinated sizes and colours', mode: 'sand' }]} />
      <BestsellerLuggageGrid products={luggage} />
      <SizeComparison sizes={[{ name: 'Cabin', copy: '2–4 day trips and overhead storage.' }, { name: 'Check-in', copy: '5–8 day trips with flexible packing.' }, { name: 'Large', copy: 'Extended travel or family packing.' }]} />
      <LoyaltyBanner benefits={['Member-only pricing', 'Early colour access', 'Repair and care guidance']} />
      <StoreLocatorStory artLabel="Indian retail store map" />
      <NewsletterFooter />
    </div>
  )
}
