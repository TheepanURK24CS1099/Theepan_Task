import ReferenceLabel from './components/shared/ReferenceLabel.jsx'
import GymsharkShowcase from './components/gymshark/GymsharkShowcase.jsx'
import MokobaraShowcase from './components/mokobara/MokobaraShowcase.jsx'

export default function App() {
  return (
    <>
      <header className="project-masthead">
        <p>Shopify reference component showcase / international + Indian</p>
        <h1>Performance energy meets colourful travel utility.</h1>
        <div>
          <p>
            Theepan SS studies Gymshark’s high-intensity performance commerce and
            Mokobara’s colour-forward Indian travel experience. All visuals are placeholders.
          </p>
          <nav aria-label="Jump to reference">
            <a href="#gymshark">01 International — Gymshark</a>
            <a href="#mokobara">02 Indian — Mokobara</a>
          </nav>
        </div>
      </header>

      <main id="main-content">
        <section id="gymshark" className="reference-wrap reference-wrap--dark">
          <ReferenceLabel
            index="01"
            reference="Gymshark"
            thesis="High-impact campaigns, activity navigation, technical product cards and community-led retention."
          />
          <GymsharkShowcase />
        </section>

        <section id="mokobara" className="reference-wrap reference-wrap--light">
          <ReferenceLabel
            index="02"
            reference="Mokobara"
            thesis="Colour-led travel discovery, size/use navigation, sale clarity, loyalty and omnichannel retail."
          />
          <MokobaraShowcase />
        </section>
      </main>

      <footer className="project-end">
        <p>Independent study — not affiliated with Gymshark, Mokobara or Shopify.</p>
        <a href="#main-content">Return to top ↑</a>
      </footer>
    </>
  )
}
